# Week 9-10: Model Evaluation and Preprocessing

Jupyter notebook: `week9_10_evaluation_preprocessing.ipynb`

## Topics
**Model evaluation**
- Train/test split
- K-fold cross-validation
- Confusion matrix
- Precision, recall, F1 score (and the effect of the threshold)
- ROC curve and ROC-AUC

**Preprocessing**
- Handling missing data (drop, mean, median)
- Scaling (Min-Max, Standardization)
- Feature engineering

A scikit-learn `Pipeline` is used so fill values and scaling numbers are learned from training data only (no data leakage).

## How to run
```
pip install -r requirements.txt
jupyter notebook week9_10_evaluation_preprocessing.ipynb
```
The notebook is saved with its outputs, so GitHub shows all tables and graphs without running anything.

## Author
Your Name - Roll No
