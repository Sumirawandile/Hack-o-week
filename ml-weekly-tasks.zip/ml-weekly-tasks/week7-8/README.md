# Week 7-8: Regression and Classification

Jupyter notebook: `week7_8_regression_classification.ipynb`

## Topics
**Regression** (predict marks from hours studied)
- Linear Regression
- Polynomial Regression (shows overfitting at high degree)
- Ridge and Lasso Regression (L2 / L1 penalty, effect of alpha, weights compared)

**Classification** (predict pass/fail from hours studied and attendance)
- Logistic Regression (decision boundary, confusion matrix)
- KNN (effect of k, decision boundaries)

## How to run
```
pip install -r requirements.txt
jupyter notebook week7_8_regression_classification.ipynb
```
The notebook is saved with its outputs, so GitHub shows all tables and graphs without running anything.

## Author
Your Name - Roll No
